#include <stdio.h>

int main() {
    float cgpa;

    // Input the CGPA
    printf("Enter the CGPA: ");
    scanf("%f", &cgpa);

    // Classify the CGPA
    if (cgpa >= 4.50 && cgpa <= 5.00) {
        printf("Class of Degree: 1st Class\n");
    } else if (cgpa >= 3.50 && cgpa < 4.50) {
        printf("Class of Degree: 2nd Class Upper\n");
    } else if (cgpa >= 2.40 && cgpa < 3.50) {
        printf("Class of Degree: 2nd Class Lower\n");
    } else if (cgpa >= 1.50 && cgpa < 2.40) {
        printf("Class of Degree: Third Class\n");
    } else if (cgpa < 1.50) {
        printf("Class of Degree: Failed\n");
    } else {
        printf("Invalid CGPA\n");
    }

    return 0;
}
