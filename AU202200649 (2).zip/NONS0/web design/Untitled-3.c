#include <stdio.h>

#define BONUS_RATE 0.15
#define MIN_RECHARGE 10000

int main() {
    int num_customers;
    printf("Enter the number of customers: ");
    scanf("%d", &num_customers);

    int recharges[num_customers];
    for (int i = 0; i < num_customers; i++) {
        printf("Enter the recharge amount for customer %d: ", i + 1);
        scanf("%d", &recharges[i]);
    }

    printf("\nCustomer\tRecharge\tBonus\n");
    for (int i = 0; i < num_customers; i++) {
        printf("%d\t\t%d\t\t", i + 1, recharges[i]);
        if (recharges[i] >= MIN_RECHARGE) {
            float bonus = recharges[i] * BONUS_RATE;
            printf("%.2f\n", bonus);
        } else {
            printf("0.00\n");
        }
    }
    // ODU NONSO AU202200649
    

    return 0;
}
